import re
from datetime import datetime


# ============================================================
# GENERIC VALIDATION FUNCTIONS
# ============================================================

def is_valid_date(date_value):
    """
    Validate dates in:
        YYYY-MM-DD
        DD/MM/YYYY
        DD-MM-YYYY
        YYYY
    """

    if not date_value:
        return False

    date_value = str(date_value).strip()

    formats = [
        "%Y-%m-%d",
        "%d/%m/%Y",
        "%d-%m-%Y",
        "%Y"
    ]

    for fmt in formats:
        try:
            datetime.strptime(date_value, fmt)
            return True
        except ValueError:
            continue

    return False


def is_valid_name(name):
    """
    Validate a person's name.
    """

    if not name:
        return False

    name = name.strip()

    if len(name) < 2:
        return False

    return bool(
        re.fullmatch(
            r"[A-Za-z][A-Za-z .'-]*",
            name
        )
    )


# ============================================================
# PASSPORT VALIDATION
# ============================================================

def validate_passport(fields):
    """
    Validate extracted passport fields.
    """

    validation = {}

    passport_number = fields.get(
        "passport_number", ""
    )

    nationality = fields.get(
        "nationality", ""
    )

    sex = fields.get(
        "sex", ""
    )

    surname = fields.get(
        "surname", ""
    )

    given_name = fields.get(
        "given_name", ""
    )

    dob = fields.get(
        "date_of_birth", ""
    )

    expiry = fields.get(
        "date_of_expiry", ""
    )

    # --------------------------------------------------------
    # Passport number
    # --------------------------------------------------------

    validation["passport_number"] = {
        "valid": bool(
            re.fullmatch(
                r"[A-Z0-9]{6,9}",
                passport_number.upper()
            )
        ),
        "message": "Valid passport number format"
        if re.fullmatch(
            r"[A-Z0-9]{6,9}",
            passport_number.upper()
        )
        else "Invalid passport number format"
    }

    # --------------------------------------------------------
    # Nationality
    # --------------------------------------------------------

    validation["nationality"] = {
        "valid": bool(
            re.fullmatch(
                r"[A-Z]{3}",
                nationality.upper()
            )
        ),
        "message": "Valid nationality code"
        if re.fullmatch(
            r"[A-Z]{3}",
            nationality.upper()
        )
        else "Invalid nationality code"
    }

    # --------------------------------------------------------
    # Sex
    # --------------------------------------------------------

    validation["sex"] = {
        "valid": sex.upper() in ["M", "F", "X"],
        "message": "Valid sex code"
        if sex.upper() in ["M", "F", "X"]
        else "Invalid sex code"
    }

    # --------------------------------------------------------
    # Surname
    # --------------------------------------------------------

    validation["surname"] = {
        "valid": is_valid_name(surname),
        "message": "Valid surname"
        if is_valid_name(surname)
        else "Invalid or missing surname"
    }

    # --------------------------------------------------------
    # Given name
    # --------------------------------------------------------

    validation["given_name"] = {
        "valid": is_valid_name(given_name),
        "message": "Valid given name"
        if is_valid_name(given_name)
        else "Invalid or missing given name"
    }

    # --------------------------------------------------------
    # Date of birth
    # --------------------------------------------------------

    validation["date_of_birth"] = {
        "valid": is_valid_date(dob),
        "message": "Valid date of birth"
        if is_valid_date(dob)
        else "Invalid or missing date of birth"
    }

    # --------------------------------------------------------
    # Expiry date
    # --------------------------------------------------------

    expiry_valid = is_valid_date(expiry)

    validation["date_of_expiry"] = {
        "valid": expiry_valid,
        "message": "Valid expiry date"
        if expiry_valid
        else "Invalid or missing expiry date"
    }

    # --------------------------------------------------------
    # Passport type
    # --------------------------------------------------------

    passport_type = fields.get(
        "passport_type", ""
    )

    validation["passport_type"] = {
        "valid": passport_type.upper() == "P",
        "message": "Valid passport type"
        if passport_type.upper() == "P"
        else "Invalid or missing passport type"
    }

    return validation


# ============================================================
# AADHAAR VALIDATION
# ============================================================

def validate_aadhaar(fields):
    """
    Validate extracted Aadhaar fields.

    QR code validation is intentionally not performed.
    """

    validation = {}

    name = fields.get(
        "name", ""
    )

    aadhaar_number = fields.get(
        "aadhaar_number", ""
    )

    dob = fields.get(
        "date_of_birth", ""
    )

    gender = fields.get(
        "gender", ""
    )

    mobile_number = fields.get(
        "mobile_number", ""
    )

    # --------------------------------------------------------
    # Name
    # --------------------------------------------------------

    validation["name"] = {
        "valid": is_valid_name(name),
        "message": "Valid name"
        if is_valid_name(name)
        else "Invalid or missing name"
    }

    # --------------------------------------------------------
    # Aadhaar number
    # --------------------------------------------------------

    aadhaar_valid = bool(
        re.fullmatch(
            r"\d{12}",
            aadhaar_number
        )
    )

    validation["aadhaar_number"] = {
        "valid": aadhaar_valid,
        "message": "Valid Aadhaar number format"
        if aadhaar_valid
        else "Invalid Aadhaar number format"
    }

    # --------------------------------------------------------
    # Date of birth / year of birth
    # --------------------------------------------------------

    dob_valid = is_valid_date(dob)

    validation["date_of_birth"] = {
        "valid": dob_valid,
        "message": "Valid date/year of birth"
        if dob_valid
        else "Invalid or missing date/year of birth"
    }

    # --------------------------------------------------------
    # Gender
    # --------------------------------------------------------

    gender_valid = gender.upper() in [
        "M",
        "F",
        "MALE",
        "FEMALE"
    ]

    validation["gender"] = {
        "valid": gender_valid,
        "message": "Valid gender"
        if gender_valid
        else "Invalid or missing gender"
    }

    # --------------------------------------------------------
    # Mobile number
    # --------------------------------------------------------

    mobile_valid = (
        not mobile_number
        or bool(
            re.fullmatch(
                r"[6-9]\d{9}",
                mobile_number
            )
        )
    )

    validation["mobile_number"] = {
        "valid": mobile_valid,
        "message": "Valid mobile number"
        if mobile_valid
        else "Invalid mobile number"
    }

    return validation


# ============================================================
# STRUCTURE VALIDATION
# ============================================================

def validate_document_structure(
    document_type,
    fields
):
    """
    Check whether the expected fields for the detected
    document type are present.
    """

    if document_type == "passport":

        required_fields = [
            "passport_type",
            "country_code",
            "passport_number",
            "surname",
            "given_name",
            "nationality",
            "sex",
            "date_of_birth",
            "date_of_expiry"
        ]

    elif document_type == "aadhaar":

        required_fields = [
            "name",
            "aadhaar_number",
            "date_of_birth",
            "gender"
        ]

    else:

        return {
            "valid": False,
            "missing_fields": [],
            "message": "Unknown document type"
        }

    missing_fields = []

    for field in required_fields:

        value = fields.get(field, "")

        if not value:
            missing_fields.append(field)

    return {
        "valid": len(missing_fields) == 0,
        "missing_fields": missing_fields,
        "message": "Document structure is complete"
        if not missing_fields
        else "Required fields are missing"
    }


# ============================================================
# DOCUMENT VALIDATION SCORE
# ============================================================

def calculate_document_score(
    field_validation,
    structure_validation
):
    """
    Calculate a simple document validation score
    from 0 to 100.
    """

    if not field_validation:
        return 0

    total_fields = len(field_validation)

    valid_fields = sum(
        1
        for result in field_validation.values()
        if result.get("valid") is True
    )

    field_score = (
        valid_fields / total_fields
    ) * 100

    # Structure completeness contributes to the result.
    if structure_validation.get("valid"):

        structure_score = 100

    else:

        missing_count = len(
            structure_validation.get(
                "missing_fields",
                []
            )
        )

        structure_score = max(
            0,
            100 - (missing_count * 15)
        )

    final_score = (
        field_score * 0.8
        +
        structure_score * 0.2
    )

    return round(
        min(100, max(0, final_score)),
        2
    )


# ============================================================
# CROSS-DOCUMENT VALIDATION
# ============================================================

def normalize_comparison_value(value):
    """
    Normalize values before comparing them across
    Passport and Aadhaar.
    """

    if value is None:
        return ""

    value = str(value).upper().strip()

    # Remove spaces and punctuation
    value = re.sub(
        r"[^A-Z0-9]",
        "",
        value
    )

    return value


def compare_fields(
    passport_value,
    aadhaar_value
):
    """
    Compare two identity fields.
    """

    passport_normalized = normalize_comparison_value(
        passport_value
    )

    aadhaar_normalized = normalize_comparison_value(
        aadhaar_value
    )

    if not passport_normalized or not aadhaar_normalized:

        return {
            "status": "NOT_AVAILABLE",
            "match": False
        }

    if passport_normalized == aadhaar_normalized:

        return {
            "status": "MATCH",
            "match": True
        }

    return {
        "status": "MISMATCH",
        "match": False
    }


def cross_document_validation(
    passport_fields,
    aadhaar_fields
):
    """
    Compare common identity fields between
    Passport and Aadhaar.

    Common fields:
        Name
        Date of Birth
        Sex / Gender
    """

    passport_name = " ".join(
        filter(
            None,
            [
                passport_fields.get("surname", ""),
                passport_fields.get("given_name", "")
            ]
        )
    )

    aadhaar_name = aadhaar_fields.get(
        "name",
        ""
    )

    passport_dob = passport_fields.get(
        "date_of_birth",
        ""
    )

    aadhaar_dob = aadhaar_fields.get(
        "date_of_birth",
        ""
    )

    passport_sex = passport_fields.get(
        "sex",
        ""
    )

    aadhaar_gender = aadhaar_fields.get(
        "gender",
        ""
    )

    name_result = compare_fields(
        passport_name,
        aadhaar_name
    )

    dob_result = compare_fields(
        passport_dob,
        aadhaar_dob
    )

    gender_result = compare_fields(
        passport_sex,
        aadhaar_gender
    )

    results = {
        "name": name_result,
        "date_of_birth": dob_result,
        "gender": gender_result
    }

    available_comparisons = [
        result
        for result in results.values()
        if result["status"] != "NOT_AVAILABLE"
    ]

    if not available_comparisons:

        overall_status = "NOT_AVAILABLE"

    elif all(
        result["match"]
        for result in available_comparisons
    ):

        overall_status = "MATCH"

    else:

        overall_status = "MISMATCH"

    return {
        "overall_status": overall_status,
        "fields": results
    }