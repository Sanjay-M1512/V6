import re
from datetime import datetime


# ============================================================
# TEXT NORMALIZATION
# ============================================================

def normalize_text(text):
    """Clean OCR text while preserving line structure."""

    if not text:
        return ""

    text = str(text).replace("\r", "\n")

    text = text.replace("—", "-")
    text = text.replace("–", "-")

    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n+", "\n", text)

    return text.strip()


def clean_value(value):
    """Clean a general OCR value."""

    if not value:
        return ""

    value = str(value).strip()
    value = re.sub(r"\s+", " ", value)

    return value.strip()


def normalize_name(name):
    """Normalize a person's name."""

    if not name:
        return ""

    name = str(name).strip()

    name = re.sub(
        r"[^A-Za-z .'-]",
        "",
        name
    )

    name = re.sub(
        r"\s+",
        " ",
        name
    )

    return name.strip().upper()


# ============================================================
# DOCUMENT TYPE DETECTION
# ============================================================

def detect_document_type(text):
    """
    Detect Passport or Aadhaar from OCR text.
    """

    text = normalize_text(text)
    upper = text.upper()

    passport_keywords = [
        "PASSPORT",
        "REPUBLIC OF INDIA",
        "COUNTRY CODE",
        "PASSPORT NO",
        "SURNAME",
        "GIVEN NAMES",
        "NATIONALITY",
        "PLACE OF BIRTH",
        "PLACE OF ISSUE",
        "DATE OF ISSUE",
        "DATE OF EXPIRY"
    ]

    aadhaar_keywords = [
        "AADHAAR",
        "UIDAI",
        "UNIQUE IDENTIFICATION",
        "YOUR AADHAAR",
        "ENROLMENT",
        "ENROLLMENT",
        "MOBILE",
        "YEAR OF BIRTH"
    ]

    passport_score = sum(
        keyword in upper
        for keyword in passport_keywords
    )

    aadhaar_score = sum(
        keyword in upper
        for keyword in aadhaar_keywords
    )

    if passport_score > aadhaar_score:
        return "passport"

    if aadhaar_score > passport_score:
        return "aadhaar"

    return "unknown"


# ============================================================
# DATE FUNCTIONS
# ============================================================

def normalize_date(date_value):
    """
    Convert:
        DD/MM/YYYY
        DD-MM-YYYY
        DD.MM.YYYY

    to:
        YYYY-MM-DD
    """

    if not date_value:
        return ""

    date_value = str(date_value).strip()

    formats = [
        "%d/%m/%Y",
        "%d-%m-%Y",
        "%d.%m.%Y"
    ]

    for fmt in formats:

        try:

            date = datetime.strptime(
                date_value,
                fmt
            )

            return date.strftime(
                "%Y-%m-%d"
            )

        except ValueError:
            continue

    return date_value


def extract_dates(text):
    """Extract normal dates from OCR text."""

    return re.findall(
        r"\b\d{2}[\/\-.]\d{2}[\/\-.]\d{4}\b",
        text
    )


# ============================================================
# PASSPORT MRZ
# ============================================================

def clean_mrz_line(line):
    """
    Clean an OCR line for MRZ processing.
    """

    if not line:
        return ""

    line = str(line).upper()

    line = re.sub(
        r"\s+",
        "",
        line
    )

    line = re.sub(
        r"[^A-Z0-9<]",
        "",
        line
    )

    return line


def find_mrz_lines(text):
    """
    Find two Passport MRZ lines.
    """

    lines = text.splitlines()

    candidates = []

    for line in lines:

        cleaned = clean_mrz_line(
            line
        )

        if len(cleaned) >= 30:

            candidates.append(
                cleaned
            )

    for i in range(
        len(candidates)
    ):

        first = candidates[i]

        if first.startswith("P"):

            if i + 1 < len(candidates):

                second = candidates[
                    i + 1
                ]

                return first, second

    return None, None


def parse_mrz_name(line1):
    """
    Extract surname and given names.

    Example:

    P<INDPALANIVEL<<MASILAMANI
    """

    if not line1:
        return "", ""

    # Remove P<XXX prefix
    name_part = line1[5:]

    parts = name_part.split(
        "<<",
        1
    )

    if len(parts) != 2:
        return "", ""

    surname = parts[0].replace(
        "<",
        " "
    )

    given_name = parts[1].replace(
        "<",
        " "
    )

    return (
        normalize_name(surname),
        normalize_name(given_name)
    )


def convert_mrz_date(value):
    """
    Convert YYMMDD into YYYY-MM-DD.
    """

    if not re.fullmatch(
        r"\d{6}",
        value or ""
    ):
        return ""

    try:

        yy = int(value[:2])
        month = int(value[2:4])
        day = int(value[4:6])

        current_year = (
            datetime.now().year % 100
        )

        if yy <= current_year:
            year = 2000 + yy
        else:
            year = 1900 + yy

        date = datetime(
            year,
            month,
            day
        )

        return date.strftime(
            "%Y-%m-%d"
        )

    except ValueError:

        return ""


def parse_mrz_text(mrz_text):
    """
    Parse the dedicated MRZ OCR result.
    """

    if not mrz_text:
        return {}

    line1, line2 = find_mrz_lines(
        mrz_text
    )

    if not line1 or not line2:
        return {}

    if len(line2) < 27:
        return {}

    surname, given_name = (
        parse_mrz_name(line1)
    )

    passport_number = (
        line2[0:9]
        .replace("<", "")
    )

    nationality = line2[10:13]

    dob_raw = line2[13:19]

    sex = line2[20:21]

    expiry_raw = line2[21:27]

    return {

        "passport_number":
            passport_number,

        "nationality":
            nationality,

        "date_of_birth":
            convert_mrz_date(
                dob_raw
            ),

        "sex":
            sex,

        "date_of_expiry":
            convert_mrz_date(
                expiry_raw
            ),

        "surname":
            surname,

        "given_name":
            given_name,

        "mrz":
            line1 + "\n" + line2
    }


# ============================================================
# PASSPORT FIELD EXTRACTION
# ============================================================

def extract_passport_number(text):
    """
    Extract Passport number from the Passport No label.
    """

    patterns = [

        r"PASSPORT\s*NO\.?\s*[:\-]?\s*([A-Z]\d{7})",

        r"PASSPORT\s*NUMBER\s*[:\-]?\s*([A-Z0-9]{6,9})",

        r"PASSPORT\s*NO\s*[:\-]?\s*([A-Z0-9]{6,9})"
    ]

    for pattern in patterns:

        match = re.search(
            pattern,
            text,
            re.IGNORECASE
        )

        if match:

            return match.group(
                1
            ).upper()

    return ""


def extract_passport_date(
    text,
    labels
):
    """
    Extract a date after a specific label.
    """

    labels_pattern = "|".join(
        re.escape(label)
        for label in labels
    )

    pattern = (
        r"(?:"
        + labels_pattern
        + r")"
        r"\s*[:.]?\s*"
        r"(\d{2}[\/\-.]\d{2}[\/\-.]\d{4})"
    )

    match = re.search(
        pattern,
        text,
        re.IGNORECASE
    )

    if match:

        return normalize_date(
            match.group(1)
        )

    return ""


def extract_passport_sex(text):
    """
    Extract M/F after Sex.
    """

    patterns = [

        r"SEX\s*[:.]?\s*(M|F)\b",

        r"SEX\s*/?\s*DATE\s+OF\s+BIRTH\s*"
        r"[:.]?\s*(M|F)\b"
    ]

    for pattern in patterns:

        match = re.search(
            pattern,
            text,
            re.IGNORECASE
        )

        if match:

            return match.group(
                1
            ).upper()

    return ""


def extract_passport_nationality(
    text
):
    """
    Extract nationality without consuming
    the following fields.
    """

    match = re.search(
        r"NATIONALITY\s*[:.]?\s*"
        r"(INDIAN|IND)\b",
        text,
        re.IGNORECASE
    )

    if not match:
        return ""

    value = match.group(
        1
    ).upper()

    if value == "IND":
        return "INDIAN"

    return value


def extract_labeled_value(
    text,
    label,
    next_labels=None
):
    """
    Extract value following a label.
    """

    if next_labels is None:
        next_labels = []

    escaped_next = [
        re.escape(label)
        for label in next_labels
    ]

    if escaped_next:

        stop_pattern = (
            "|".join(
                escaped_next
            )
        )

        pattern = (
            re.escape(label)
            + r"\s*[:.]?\s*"
            + r"(.+?)"
            + r"(?=\b(?:"
            + stop_pattern
            + r")\b|$)"
        )

    else:

        pattern = (
            re.escape(label)
            + r"\s*[:.]?\s*(.+)"
        )

    match = re.search(
        pattern,
        text,
        re.IGNORECASE
    )

    if not match:
        return ""

    return clean_value(
        match.group(1)
    )


def extract_passport_place(
    text,
    label
):
    """
    Extract passport place fields.
    """

    next_labels = [
        "PLACE OF BIRTH",
        "PLACE OF ISSUE",
        "DATE OF ISSUE",
        "DATE OF EXPIRY",
        "NATIONALITY",
        "SEX"
    ]

    value = extract_labeled_value(
        text,
        label,
        next_labels
    )

    return value.upper()


# ============================================================
# PASSPORT PARSER
# ============================================================

def parse_passport(
    general_text,
    mrz_text=""
):
    """
    Parse Passport using both:

        General OCR
        Dedicated MRZ OCR

    MRZ is preferred for:
        Passport number
        Nationality
        DOB
        Sex
        Expiry
        Name
    """

    general_text = normalize_text(
        general_text
    )

    mrz_text = normalize_text(
        mrz_text
    )

    fields = {

        "passport_type": "",

        "country_code": "",

        "passport_number": "",

        "surname": "",

        "given_name": "",

        "nationality": "",

        "sex": "",

        "date_of_birth": "",

        "place_of_birth": "",

        "place_of_issue": "",

        "date_of_issue": "",

        "date_of_expiry": "",

        "mrz": "",

        "signature": ""
    }


    # ========================================================
    # PASSPORT TYPE
    # ========================================================

    if re.search(
        r"\bTYPE\s*[:.]?\s*P\b",
        general_text,
        re.IGNORECASE
    ):

        fields["passport_type"] = "P"


    # ========================================================
    # COUNTRY CODE
    # ========================================================

    if re.search(
        r"\bIND\b",
        general_text.upper()
    ):

        fields["country_code"] = "IND"


    # ========================================================
    # DEDICATED MRZ
    # ========================================================

    mrz_data = parse_mrz_text(
        mrz_text
    )


    # ========================================================
    # USE MRZ VALUES FIRST
    # ========================================================

    if mrz_data:

        fields["passport_number"] = (
            mrz_data.get(
                "passport_number",
                ""
            )
        )

        fields["nationality"] = (
            mrz_data.get(
                "nationality",
                ""
            )
        )

        fields["date_of_birth"] = (
            mrz_data.get(
                "date_of_birth",
                ""
            )
        )

        fields["sex"] = (
            mrz_data.get(
                "sex",
                ""
            )
        )

        fields["date_of_expiry"] = (
            mrz_data.get(
                "date_of_expiry",
                ""
            )
        )

        fields["surname"] = (
            mrz_data.get(
                "surname",
                ""
            )
        )

        fields["given_name"] = (
            mrz_data.get(
                "given_name",
                ""
            )
        )

        fields["mrz"] = (
            mrz_data.get(
                "mrz",
                ""
            )
        )


    # ========================================================
    # PASSPORT NUMBER FALLBACK
    # ========================================================

    if not fields["passport_number"]:

        fields["passport_number"] = (
            extract_passport_number(
                general_text
            )
        )


    # ========================================================
    # NATIONALITY FALLBACK
    # ========================================================

    if not fields["nationality"]:

        fields["nationality"] = (
            extract_passport_nationality(
                general_text
            )
        )


    # ========================================================
    # SEX FALLBACK
    # ========================================================

    if not fields["sex"]:

        fields["sex"] = (
            extract_passport_sex(
                general_text
            )
        )


    # ========================================================
    # DOB FALLBACK
    # ========================================================

    if not fields["date_of_birth"]:

        fields["date_of_birth"] = (
            extract_passport_date(
                general_text,
                [
                    "DATE OF BIRTH"
                ]
            )
        )


    # ========================================================
    # ISSUE DATE
    # ========================================================

    fields["date_of_issue"] = (
        extract_passport_date(
            general_text,
            [
                "DATE OF ISSUE"
            ]
        )
    )


    # ========================================================
    # EXPIRY FALLBACK
    # ========================================================

    if not fields["date_of_expiry"]:

        fields["date_of_expiry"] = (
            extract_passport_date(
                general_text,
                [
                    "DATE OF EXPIRY"
                ]
            )
        )


    # ========================================================
    # SURNAME FALLBACK
    # ========================================================

    if not fields["surname"]:

        surname = extract_labeled_value(
            general_text,
            "SURNAME",
            [
                "GIVEN NAMES",
                "GIVEN NAME",
                "NATIONALITY"
            ]
        )

        fields["surname"] = (
            normalize_name(
                surname
            )
        )


    # ========================================================
    # GIVEN NAME FALLBACK
    # ========================================================

    if not fields["given_name"]:

        given_name = extract_labeled_value(
            general_text,
            "GIVEN NAMES",
            [
                "NATIONALITY",
                "SEX",
                "DATE OF BIRTH"
            ]
        )

        fields["given_name"] = (
            normalize_name(
                given_name
            )
        )


    # ========================================================
    # PLACE OF BIRTH
    # ========================================================

    fields["place_of_birth"] = (
        extract_passport_place(
            general_text,
            "PLACE OF BIRTH"
        )
    )


    # ========================================================
    # PLACE OF ISSUE
    # ========================================================

    fields["place_of_issue"] = (
        extract_passport_place(
            general_text,
            "PLACE OF ISSUE"
        )
    )


    return fields


# ============================================================
# AADHAAR EXTRACTION
# ============================================================

def extract_aadhaar_number(text):
    """
    Extract 12-digit Aadhaar number.
    """

    patterns = [

        r"\b\d{4}\s+\d{4}\s+\d{4}\b",

        r"\b\d{12}\b"
    ]

    for pattern in patterns:

        matches = re.findall(
            pattern,
            text
        )

        for value in matches:

            number = re.sub(
                r"\D",
                "",
                value
            )

            if len(number) == 12:

                return number

    return ""


def extract_mobile_number(text):
    """
    Extract Indian mobile number.
    """

    matches = re.findall(
        r"\b[6-9]\d{9}\b",
        text
    )

    if matches:

        return matches[0]

    return ""


def extract_aadhaar_gender(text):
    """
    Extract Aadhaar gender.
    """

    upper = text.upper()

    if re.search(
        r"\bFEMALE\b",
        upper
    ):
        return "FEMALE"

    if re.search(
        r"\bMALE\b",
        upper
    ):
        return "MALE"

    return ""


def extract_aadhaar_dob(text):
    """
    Extract Aadhaar DOB.
    """

    match = re.search(
        r"(?:DOB|DATE OF BIRTH)"
        r"\s*[:\-]?\s*"
        r"(\d{2}[\/\-.]\d{2}[\/\-.]\d{4})",
        text,
        re.IGNORECASE
    )

    if match:

        return normalize_date(
            match.group(1)
        )

    dates = extract_dates(
        text
    )

    if dates:

        return normalize_date(
            dates[0]
        )

    return ""


def extract_aadhaar_name(text):
    """
    Extract Aadhaar name from OCR.

    Handles common layouts where the name appears
    after 'To'.
    """

    lines = [
        line.strip()
        for line in text.splitlines()
        if line.strip()
    ]

    # --------------------------------------------------------
    # Search after "TO"
    # --------------------------------------------------------

    for i, line in enumerate(lines):

        if line.upper() == "TO":

            candidates = lines[
                i + 1:i + 5
            ]

            for candidate in candidates:

                upper = candidate.upper()

                if (
                    "S/O" in upper
                    or "D/O" in upper
                    or "W/O" in upper
                ):
                    continue

                if (
                    "AADHAAR" in upper
                    or "GOVERNMENT" in upper
                    or "INDIA" == upper
                ):
                    continue

                if re.fullmatch(
                    r"[A-Za-z][A-Za-z .'-]{2,}",
                    candidate
                ):

                    return normalize_name(
                        candidate
                    )

    # --------------------------------------------------------
    # Name label fallback
    # --------------------------------------------------------

    match = re.search(
        r"\bNAME\s*[:\-]\s*"
        r"([A-Za-z][A-Za-z .'-]+)",
        text,
        re.IGNORECASE
    )

    if match:

        return normalize_name(
            match.group(1)
        )

    return ""


def extract_aadhaar_address(text):
    """
    Basic address extraction.
    """

    lines = [
        line.strip()
        for line in text.splitlines()
        if line.strip()
    ]

    start = -1

    for i, line in enumerate(lines):

        if re.search(
            r"\b(S/O|D/O|W/O)\b",
            line,
            re.IGNORECASE
        ):

            start = i
            break

    if start == -1:
        return ""

    address_lines = []

    for line in lines[start:]:

        upper = line.upper()

        if (
            "AADHAAR" in upper
            or "MOBILE" in upper
        ):
            break

        address_lines.append(
            line
        )

    return ", ".join(
        address_lines
    )


# ============================================================
# AADHAAR PARSER
# ============================================================

def parse_aadhaar(
    general_text,
    aadhaar_text=""
):
    """
    Parse Aadhaar using the dedicated Aadhaar OCR
    result when available.
    """

    # Prefer focused Aadhaar OCR
    if aadhaar_text:

        text = normalize_text(
            aadhaar_text
        )

        # Also retain general OCR for fields that
        # may exist outside the focused region.
        combined_text = (
            text
            + "\n"
            + normalize_text(
                general_text
            )
        )

    else:

        combined_text = normalize_text(
            general_text
        )


    fields = {

        "name": "",

        "date_of_birth": "",

        "gender": "",

        "aadhaar_number": "",

        "mobile_number": "",

        "address": ""
    }


    fields["aadhaar_number"] = (
        extract_aadhaar_number(
            combined_text
        )
    )

    fields["mobile_number"] = (
        extract_mobile_number(
            combined_text
        )
    )

    fields["gender"] = (
        extract_aadhaar_gender(
            combined_text
        )
    )

    fields["date_of_birth"] = (
        extract_aadhaar_dob(
            combined_text
        )
    )

    fields["name"] = (
        extract_aadhaar_name(
            combined_text
        )
    )

    fields["address"] = (
        extract_aadhaar_address(
            combined_text
        )
    )


    return fields


# ============================================================
# MAIN DOCUMENT PARSER
# ============================================================

def parse_document(
    ocr_result
):
    """
    Main parser.

    Accepts the complete OCR result from ocr_service.py.
    """

    # --------------------------------------------------------
    # Extract OCR sections
    # --------------------------------------------------------

    if isinstance(
        ocr_result,
        str
    ):

        general_text = ocr_result
        mrz_text = ""
        aadhaar_text = ""

    else:

        general = ocr_result.get(
            "general",
            {}
        )

        mrz = ocr_result.get(
            "mrz",
            {}
        )

        aadhaar = ocr_result.get(
            "aadhaar",
            {}
        )

        general_text = general.get(
            "text",
            ""
        )

        mrz_text = mrz.get(
            "text",
            ""
        )

        aadhaar_text = aadhaar.get(
            "text",
            ""
        )

        # If general OCR is unavailable,
        # use combined OCR text.
        if not general_text:

            general_text = ocr_result.get(
                "text",
                ""
            )


    # --------------------------------------------------------
    # Detect document
    # --------------------------------------------------------

    document_type = detect_document_type(
        general_text
    )


    # --------------------------------------------------------
    # Passport
    # --------------------------------------------------------

    if document_type == "passport":

        fields = parse_passport(
            general_text,
            mrz_text
        )


    # --------------------------------------------------------
    # Aadhaar
    # --------------------------------------------------------

    elif document_type == "aadhaar":

        fields = parse_aadhaar(
            general_text,
            aadhaar_text
        )


    # --------------------------------------------------------
    # Unknown
    # --------------------------------------------------------

    else:

        fields = {}


    return {

        "document_type":
            document_type,

        "fields":
            fields
    }